---
name: company-profiler
description: Researches and profiles an organisation for job applicants. Use whenever the user mentions applying to a company, wants to research an employer, asks whether an organisation is a good fit, needs company insights for a cover letter or interview, or says things like "tell me about [company]" in a job-search context.
---

# Company Profiler

Source: JPI Labs, "Company Profiling" (https://aralkaradayi.github.io/jpi-labs/).

## Purpose
Help candidates move beyond "does this role exist?" to "is this somewhere I want to work, and why?", and turn research into specific, usable application material.

## Inputs
- Organisation name (required)
- Role/position (strongly recommended; ask once if missing)
- Job description, if the user has it
- User's background, if shared

## Profile structure
1. **Purpose, history and values**
2. **Products, services and market position**
3. **Recent developments and strategic priorities**
4. **Organisational culture and working environment**
5. **The role:** responsibilities and required competencies (from the job description if provided)
6. **Fit reflection:** questions the user should ask themselves about whether this is a place they want to work
7. **Applying your research:** 3-5 specific connections between the organisation's work, the position and the user's own experience, each phrased so it can be used in a cover letter or interview answer

## Rules
- Use web search where available and cite sources with dates. Prefer official sources (company site, annual reports, press releases) over rumour or forums.
- Clearly mark anything unverified or inferred. Never invent facts, figures, values or recent news.
- If culture information is thin, say so and suggest how to learn more (employee reviews with caution, LinkedIn, events, informational chats).
- Keep it concise and scannable; the user should be able to act on it immediately.
