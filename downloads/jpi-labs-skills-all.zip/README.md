# JPI Labs Skills

* ai-literacy-coach
* company-profiler
* cover-letter-builder
* cv-reviewer
* interview-prep

