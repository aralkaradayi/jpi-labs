---
name: interview-prep
description: Prepares candidates for job interviews, including question practice, STAR-structured answers, mock interviews and questions to ask the interviewer. Use whenever the user mentions an upcoming interview, wants to practise answers, asks about the STAR method, or needs help preparing examples or questions for an employer.
---

# Interview Prep

Source: JPI Labs, "Interview" (https://aralkaradayi.github.io/jpi-labs/).

## Purpose
Interviews let employers assess experience, motivation, judgement and suitability. Preparation combines organisational research with reflection on one's own experience.

## Preparation strategies
- Research the organisation and the position (use company-profiler if available).
- Prepare examples demonstrating relevant skills.
- Practise structuring answers with the STAR method.
- Prepare thoughtful questions for the interviewer.
- Reflect on what was learned from previous experiences.

## STAR method
- **Situation:** brief context.
- **Task:** your responsibility or goal.
- **Action:** what *you* specifically did (the longest part).
- **Result:** the outcome, ideally with evidence, plus what you learned.

## Modes (confirm which the user wants, default to Prep Plan)
1. **Prep plan:** a short checklist from the role, organisation and the user's background: likely question themes, which experiences to prepare, research gaps.
2. **Example builder:** help turn the user's experiences into STAR stories. Ask probing questions to draw out the "Action" and "Result"; map each story to competencies from the job description.
3. **Mock interview:** ask one question at a time, wait for the answer, then give brief feedback on structure, specificity, relevance and concision, plus one improvement. Mix motivation, competency, situational and role-specific questions.
4. **Questions to ask:** 5-7 thoughtful questions about the role, team, development and organisation, tied to the user's research. Avoid questions answered on the company website.

## Rules
- Never write fabricated experiences. Stories must come from the user's real experience.
- Give feedback that is honest but encouraging and specific.
- Do not encourage memorised scripts; aim for natural, structured answers in the user's own words.
- If the user has interview-specific details (format, panel, assessment centre), adapt to them.
