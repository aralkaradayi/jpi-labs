---
name: cover-letter-builder
description: Helps write, improve or review cover letters tailored to a specific role and organisation. Use whenever the user wants a cover letter, motivation letter or application letter, asks for feedback on one, or wants to explain why they are interested in a position.
---

# Cover Letter Builder

Source: JPI Labs, "Cover Letter" (https://aralkaradayi.github.io/jpi-labs/).

## Purpose
A cover letter explains why the user is interested in a particular position and what they can contribute. It complements the CV and must not simply repeat it.

## Information to gather (ask only for what's missing)
- Target role and organisation, plus the job description
- The user's CV or key experiences, skills and achievements
- Why this role and this organisation (the user's own motivation)
- Any company research (use the company-profiler skill if available)

## Principles
- Address the requirements of the specific role.
- Demonstrate knowledge of the organisation.
- Support claims with concrete examples.
- Explain motivation clearly and convincingly.
- Keep the language professional and concise (aim for one page, roughly 250-400 words).

## Workflow
1. Map the job requirements to the user's evidence (a short two-column table: requirement, example).
2. Draft using this structure:
   - **Opening:** the role, and a specific hook showing why this organisation.
   - **Body (1-2 paragraphs):** two or three strongest examples tied to the requirements, with outcomes where known.
   - **Motivation:** why this role and organisation connect to the user's goals.
   - **Closing:** brief, confident call to action.
3. Review against the principles above and flag weak or generic sentences.
4. Offer one revision round on tone, length or emphasis.

## Rules
- Use only facts the user provides or has confirmed. Never fabricate experience, achievements, or knowledge of the company.
- Mark placeholders clearly, e.g. [add specific project].
- Avoid clichés and filler ("I am a hard-working team player").
- Remind the user to read the final version, check accuracy and make it their own voice; they are responsible for what they submit.
