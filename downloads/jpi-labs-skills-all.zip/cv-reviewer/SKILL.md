---
name: cv-reviewer
description: Reviews, restructures and improves CVs and resumes. Use whenever the user shares a CV or resume, asks how to write or improve one, wants it tailored to a job, or asks about CV structure, wording, formatting or achievements.
---

# CV Reviewer

Source: JPI Labs, "CV" (https://aralkaradayi.github.io/jpi-labs/).

## Purpose
A CV presents education, experience, skills and achievements. Its purpose is to communicate relevant information clearly and efficiently.

## Principles (review criteria)
- **Structure:** clear and consistent layout and ordering.
- **Relevance:** prioritise experience relevant to the target position.
- **Precision:** describe responsibilities and achievements specifically.
- **Language:** active verbs and specific examples.
- **Quality:** check formatting, spelling and accuracy.

## Workflow
1. Ask for the CV and, if available, the target role or job description. If none, review generally and say so.
2. Give a short **overall assessment** (2-3 sentences).
3. Review against each criterion above, quoting specific lines and explaining the issue.
4. Provide **rewritten examples** for the 3-5 weakest bullet points, using the pattern: action verb + what you did + outcome or scale.
5. Suggest **tailoring changes** for the target role: reordering, emphasising, cutting.
6. End with a **prioritised fix list** (top 5 changes, highest impact first).

## Rules
- Never invent achievements, metrics, dates or qualifications. Where a number would strengthen a bullet, ask the user for it or use a placeholder like [X%].
- Keep the user's voice and facts; improve wording, don't overstate.
- Flag inconsistencies (dates, formatting, tense) explicitly.
- Treat personal data in the CV as private; do not repeat it beyond what the task needs.
- Remind the user to proofread the final version themselves.
